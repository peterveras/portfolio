# THANK YOU FOR PURCHASINAG THIS TEMPLATE

Go to this page to see the documentacion on how to use and change this template:

http://peterveras.com/toucan/documentation/index.html


To change the color of the highlight color on your template follow these steps:

1) go to line 18 on all of your html pages, it will look like this: <link href="css/mint.css" rel="stylesheet">

2) change the file this path directs to, right now it directs to "mint.css" you can make it go to any of the other colors we left for you, choose from yellow, neon-green, blue, purple,etc. Save and reload.

Done!

